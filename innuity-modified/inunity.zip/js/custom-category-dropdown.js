jQuery(document).ready(function ($) {
    // Get the current category ID (if it's a single post)
    var currentCategory = categoryData.categoryId;

    // Populate the dropdown with posts from the same category via AJAX
    $.ajax({
        type: 'GET',
        url: categoryData.ajaxUrl,
        data: {
            action: 'get_posts_by_category',
            category_id: currentCategory,
        },
        success: function (response) {
            var dropdown = $('#category-post-dropdown');
            dropdown.empty(); // Clear existing options

            // Parse the JSON response and populate the dropdown
            var posts = JSON.parse(response);
            if (posts.length > 0) {
                $.each(posts, function (index, post) {
                    dropdown.append($('<option>').text(post.post_title).attr('value', post.guid));
                });
            } else {
                dropdown.append($('<option>').text('No posts in this category').attr('disabled', 'disabled').attr('selected', 'selected'));
            }

            // Handle the dropdown change event
            dropdown.on('change', function () {
                var selectedPost = $(this).val();
                if (selectedPost) {
                    window.location.href = selectedPost;
                }
            });
        },
        error: function (error) {
            console.error('Error fetching posts by category:', error);
        },
    });
});
