# wp-mangareader-plugin
a super simple manga reader that works with most wordpress themes.
not yet completed: if you want to test out the plugin a zip file is provided as well as the code. Currently all the reader does is detects images from the shortcode and displays it in a reader view. Using arrow keys will navigate between the images and reaching the last image will notify the user. Also users can switch between paged/list view for the images. 

shortcode example: [manga_reader images="image1.jpg, image2.jpg, image3.jpg"]

Will add an option for a custom_field later that will insert the image links automatically into the shortcode format
